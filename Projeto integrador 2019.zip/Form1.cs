﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CassLyne_GL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bt1_Click(object sender, EventArgs e)
        {
            string Usuario, Senha;
            Usuario = txtLogin.Text;
            Senha = txtSenha.Text;
            if ((Usuario == "Admin") && (Senha == "1234"))
            {
                Form2 F2 = new Form2();
                F2.Show();
            }
            else
            {
                MessageBox.Show("Usuario ou senha incorretos");
                txtLogin.Clear();
                txtSenha.Clear();
                txtLogin.Focus();
            }
        }

        private void bt2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bt3_Click(object sender, EventArgs e)
        {
            Form3 F3 = new Form3();
            F3.Show();
        }
    }
}
